import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import message_filters
import numpy as np
import cv2

# ROS 2 내비게이션 표준 메시지
from nav_msgs.msg import OccupancyGrid, MapMetaData
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point

from .inference_engine import SegformerEngine
from .inference_engine import NYURGBDEngine
from .depth_filter import DepthNoiseFilter
from .semantic_costmap import SemanticCostmapGenerator 
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy

class ExperimentNode(Node):
    def __init__(self):
        super().__init__('experiment_segmentation_node')
        self.bridge = CvBridge()

        
        # 1. 파라미터 선언 및 정의 (이 부분이 반드시 명시되어야 합니다)
        self.declare_parameter('mode', 1)
        self.mode = self.get_parameter('mode').value
        
        self.get_logger().info(f"=== 현재 실험 모드: {self.mode} ===")

        # 2. 모델 엔진 초기화 (이후 코드 계속...)
        if self.mode in [1, 2]:
            self.engine = SegformerEngine()
        elif self.mode in [3, 4]:
            self.engine = NYURGBDEngine()

        self.depth_filter = DepthNoiseFilter(
            camera_height=0.56, camera_pitch_deg=0.0, fx=388.176, fy=387.717, 
            cx=323.138, cy=246.427, height_tolerance=0.15)
        
        self.costmap_gen = SemanticCostmapGenerator(
            resolution=0.05, width=6.0, height=6.0, fx=388.176, fy=387.717, 
            cx=323.138, cy=246.427, camera_height=0.56)

        self.sub_rgb = message_filters.Subscriber(self, Image, '/d456_camera/color/image_raw')
        #self.sub_depth = message_filters.Subscriber(self, Image, '/d456_camera/depth/recovered_image')
        self.sub_depth = message_filters.Subscriber(self, Image, '/d456_camera/depth/image_rect_raw')

        self.ts = message_filters.ApproximateTimeSynchronizer([self.sub_rgb, self.sub_depth], 10, 0.1)
        self.ts.registerCallback(self.sync_callback)

        # 4개의 마스크 토픽 발행자
        self.pub_floor = self.create_publisher(Image, '/segmentation/floor_mask', 10)
        self.pub_wall = self.create_publisher(Image, '/segmentation/wall_mask', 10)
        self.pub_ceiling = self.create_publisher(Image, '/segmentation/ceiling_mask', 10)
        self.pub_object = self.create_publisher(Image, '/segmentation/object_mask', 10)
        
        # 오버레이 영상 및 코스트맵/마커 퍼블리셔
        self.pub_overlay = self.create_publisher(Image, '/segmentation/overlay_image', 10)
        
        qos_profile = QoSProfile(depth=10, durability=QoSDurabilityPolicy.TRANSIENT_LOCAL, reliability=QoSReliabilityPolicy.RELIABLE)
        self.pub_costmap = self.create_publisher(OccupancyGrid, '/segmentation/local_costmap', qos_profile)
        self.pub_blind_spot = self.create_publisher(Marker, '/segmentation/blind_spot_marker', 10)

    def sync_callback(self, rgb_msg, depth_msg):
        cv_rgb = self.bridge.imgmsg_to_cv2(rgb_msg, "rgb8")
        cv_depth = self.bridge.imgmsg_to_cv2(depth_msg, "32FC1") 

        # 1. 모델 추론
        wall, floor, ceiling, obj, obj_details = self.engine.infer(cv_rgb, cv_depth)

        # 🌟 모드에 따른 바닥 필터링 분기 (모드 1, 3은 필터링 없이 순수 마스크 사용)
        if self.mode in [2, 4]:
            final_floor = self.depth_filter.refine_floor_mask(floor, cv_depth)
        else:
            final_floor = floor # RGB 전용 모드는 원본 마스크 그대로 사용

        header = rgb_msg.header
        
        # 2. 마스크 발행
        self.pub_floor.publish(self.bridge.cv2_to_imgmsg(final_floor, "mono8", header=header))
        self.pub_wall.publish(self.bridge.cv2_to_imgmsg(wall, "mono8", header=header))
        self.pub_ceiling.publish(self.bridge.cv2_to_imgmsg(ceiling, "mono8", header=header))
        self.pub_object.publish(self.bridge.cv2_to_imgmsg(obj, "mono8", header=header))

        # 3. 오버레이 및 코스트맵 생성 (반드시 필터링된 final_floor 사용)
        overlay = self.create_overlay_image(cv_rgb, wall, final_floor, ceiling, obj_details)
        self.pub_overlay.publish(self.bridge.cv2_to_imgmsg(overlay, "rgb8", header=header))

        local_costmap_2d = self.costmap_gen.generate_costmap(final_floor)
        self.publish_costmap_msg(local_costmap_2d, header)
        self.publish_blind_spot_marker(header)

    def create_overlay_image(self, cv_rgb, wall, floor, ceiling, objects_dict):
        overlay = np.zeros_like(cv_rgb)
        colors = {'Floor': (0, 255, 0), 'Wall': (128, 128, 128), 'Ceiling': (0, 0, 255), 
                  'Door': (255, 165, 0), 'Window': (0, 255, 255), 'Glass': (200, 200, 0), 'Trash': (255, 0, 0)}
        
        masks = {'Floor': floor, 'Wall': wall, 'Ceiling': ceiling, **objects_dict}
        detected = []

        for label, mask in masks.items():
            if mask is not None and cv2.countNonZero(mask) > 500:
                detected.append(label)
                overlay[mask == 255] = colors[label]
                if label in ['Door', 'Window', 'Trash', 'Glass']:
                    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                    for cnt in contours:
                        if cv2.contourArea(cnt) > 800:
                            M = cv2.moments(cnt)
                            if M["m00"] != 0:
                                cX, cY = int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"])
                                cv2.putText(overlay, label, (cX-20, cY), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        blended = cv2.addWeighted(cv_rgb, 0.6, overlay, 0.4, 0)
        y_off = 30
        for l in detected:
            cv2.putText(blended, l, (blended.shape[1]-120, y_off), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,0), 4)
            cv2.putText(blended, l, (blended.shape[1]-120, y_off), cv2.FONT_HERSHEY_SIMPLEX, 0.7, colors[l], 2)
            y_off += 30
        return blended

    def publish_costmap_msg(self, costmap_array, header):
        grid = OccupancyGrid()
        grid.header = header
        grid.info = MapMetaData()
        grid.info.resolution = float(self.costmap_gen.res)
        grid.info.width, grid.info.height = int(self.costmap_gen.grid_w), int(self.costmap_gen.grid_h)
        grid.info.origin.position.x = - (grid.info.width * grid.info.resolution) / 2.0
        grid.info.origin.position.y = 0.56
        grid.info.origin.orientation.x = 0.7071068
        grid.info.origin.orientation.w = 0.7071068
        grid.data = costmap_array.flatten().astype(np.int8).tolist()
        self.pub_costmap.publish(grid)

    def publish_blind_spot_marker(self, header):
        pts = self.costmap_gen.get_blind_spot_points()
        y, z, limit = pts['y'], pts['z_min'], pts['limit_x']
        line, poly = Marker(), Marker()
        line.header, poly.header = header, header
        line.type, poly.type = Marker.LINE_STRIP, Marker.TRIANGLE_LIST
        line.scale.x = 0.04
        line.color.r = 1.0; line.color.a = 1.0
        poly.color.r = 1.0; poly.color.g = 0.95; poly.color.b = 0.8; poly.color.a = 0.4
        line.points = [Point(x=-limit, y=y, z=pts['z_hit_l']), Point(x=pts['x_l'], y=y, z=z), Point(x=pts['x_r'], y=y, z=z), Point(x=limit, y=y, z=pts['z_hit_right'])]
        self.pub_blind_spot.publish(line)
        self.pub_blind_spot.publish(poly)

def main(args=None):
    rclpy.init(args=args)
    node = ExperimentNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()